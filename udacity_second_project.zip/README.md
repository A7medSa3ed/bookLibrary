Hello, 
THis is the second project of Udacity nd track
the main purpose of this project , how to use react and deal with state , props, component, life hooks, and react router.
you can run this project in developer Mode by run this script (npm run start) 
you can add book to read shelf, want to read or currently reading and you can remove book from your library
you can add books to your library by search the book and add to your library
